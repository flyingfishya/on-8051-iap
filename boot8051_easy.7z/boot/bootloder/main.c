#include <REGX52.H>

#define USER_PROGRAM_ADDRESS 0x1000

typedef void (*USER_PROGRAM_ENTRY)();

unsigned int n = 0;

void delay(unsigned int i)
{
	while(i--);
}


void jump_to_user_program()
{
	  USER_PROGRAM_ENTRY user_program_entry = (USER_PROGRAM_ENTRY)USER_PROGRAM_ADDRESS;
    EA = 0;
    user_program_entry();
}
	

void main()
{
	while(1)
	{
		P2 = ~(0X01<<n);
		delay(10000);
		n++;
		if(n>=8)
		{
				jump_to_user_program();
		}
	}
}