#include <REGX52.H>

sbit led2 = P2^5;

void delay(unsigned int i)
{
	while(i--);
}

void main()
{
	P2=0XFF;
	while(1)
	{
		led2 = 0;
		delay(2500);
		led2 = 1;
		delay(2500);
	}

}